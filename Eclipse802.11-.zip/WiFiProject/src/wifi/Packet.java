package wifi;

/**
 * A class to represent an 802.11~ frame.
 * @author Nate Olderman
 * @author Brandon Roberts
 *
 */
public class Packet {
	
	//control information
	private short retry; //retry bit if the packet is being resent
	private short seqNum; //sequence number of the packet
	private short frameType;
	
	private short destAddr; //destination address for packet
	private short srcAddr; //source address for packet
	
	private byte[] data; //packet's data only (without frame)
	private byte[] packet; //the packet in it's entirety
	
	private boolean isACKed; //if this packet has been ACKed
	
	private int retryAttempts;

	
	/**
	 * Compiles the packet from the various information that makes up the packet
	 * @param frameType the type of frame to make
	 * @param destination the packet's destination address
	 * @param source the packet's source address
	 * @param data the actual data being sent
	 */
	public Packet(short typeOfFrame, short sequenceNum, short destination, short source, byte[] theData){
		frameType = typeOfFrame; //putting into control temporarily
		seqNum = sequenceNum;
		destAddr = destination;
		srcAddr = source;
		data = theData;
		retryAttempts = 0;
	}

	/**
	 * Creates a Packet from a byte array
	 * @param the byte array received from the rf layer
	 */
	public Packet(byte[] recvPacket){
		packet = recvPacket;

		//build individual pieces of control
		frameType = (short)((recvPacket[0] & 0xF0) >> 4);//get out the FrameType and the Retry bit in one number
		retry = (short)(frameType % 2);//if it is odd, then the retry bit (that was the least significant bit in this 4 bit number) was 1
		frameType >>= 1;//shift over to get rid of retry bit
		seqNum = (short) ((short)((recvPacket[0] << 8 ) + recvPacket[1]) & 0xFFF);//pull out sequence number

		//destination bytes
		destAddr = (short) (((recvPacket[2] & 0xFF) << 8) + (recvPacket[3] & 0xFF));
		
		//source bytes
		srcAddr = (short) (((recvPacket[4] & 0xFF) << 8) + (recvPacket[5] & 0xFF));
		
		//data bytes
		data = new byte[recvPacket.length - 10];
		System.arraycopy(recvPacket, 6, data, 0, data.length);
	}
	
	/**
	 * Turns the Packet information (control, destAddr, srcAddr, buffer, and CRC) into an array of bytes
	 * FOR SENDING ONLY
	 * @return the byte array representing the frame to transmit
	 */
	public byte[] toBytes(){
		byte[] buffer = new byte[data.length + 10];
		
		//build control piece
		buffer[0] = (byte) ((byte)(frameType << 1) + retry);
		buffer[0]  = (byte) ((buffer[0] << 4) + (seqNum >>> 8  & 0xF));
		buffer[1] = (byte) (seqNum & 0xFF);
		
		//destination bytes
		buffer[2] = (byte) (destAddr >>> 8);
		buffer[3] = (byte) (destAddr & 0xFF);
		
		//source bytes
		buffer[4] = (byte) (srcAddr >>> 8);
		buffer[5] = (byte) (srcAddr & 0xFF);
		
		//data bytes
		int bufferPos = 6;
		for(int i = 0; i < data.length; i++) //do the entire data and not minus 1
			buffer[bufferPos++] = data[i];
		
		//CRC bytes filled to all ones
		for(int i = buffer.length-1; i > buffer.length - 5; i--)
			buffer[i] = (byte) -1;
		return buffer;
	}
	
	/**
	 * Sets the retry bit and returns the number of times this packet has been retransmitted
	 */
	public int retry(){
		retry = 1;
		return retryAttempts++;
	}
	
	
	/**
	 * String representation of the Packet
	 */
	public String toString(){
		return ("FrameType " + frameType + " Retry " + retry + " Sequence Number " + seqNum + " | " + destAddr + " | " + srcAddr + " | " + data);
	}
	
	//---------------------------------------------------------------------------------------------------//
	//---------------------------------------- Getters & Setters ----------------------------------------//
	//---------------------------------------------------------------------------------------------------//
	/**
	 * Gives the data message back in byte form.
	 * @return the data as a byte array
	 */
	public byte[] getDatabuf(){
		return data;
	}
	
	/**
	 * Returns the ENTIRE packet's data
	 * @return the entire packet's data
	 */
	public byte[] getPacket(){
		return packet;
	}
	
	/**
	 * Gives the source address back in byte form.
	 * @return the srcAddr as a short
	 */
	public short getSrcAddr(){
		return srcAddr;
	}
	
	/**
	 * Gives the destination address back in byte form.
	 * @return the destAdr as a short
	 */
	public short getDestAddr(){
		return destAddr;
	}
	
	/**
	 * Determines if the Packet has been ACKed by the other host
	 * Sender checks so that it can remove the packet from the QUEUE
	 * @return true if this packet has been ACKed
	 */
	public boolean isAcked() {
		return isACKed;
	}
	
	/**
	 * Sets this packet as being ACKed by the other host
	 * Receiver sets this packet as being ACKed once it receives the ACK for this packet
	 */
	public void setAsAcked(){
		isACKed = true;
	}
	
	/**
	 * Gives back the type of the frame
	 * @return 0 if Data, 1 if ACK, 2 if Beacon, 4 if CTS, 5 if RTS
	 */
	public short getFrameType(){
		return frameType;
	}
	
	/**
	 * Changes the packet to an ACK
	 */
	public void makeIntoACK() {
		frameType = 1;//make it an ACK type
		
		//flip the destination and source
		short temp = destAddr;
		destAddr = srcAddr;
		srcAddr = temp;
	}
	
	public short getSeqNum(){
		return seqNum;
	}
	
	/**
	 * Set seqNum
	 */
	public void setSeqNum(short sequenceNum){
		seqNum = sequenceNum;
	}
}