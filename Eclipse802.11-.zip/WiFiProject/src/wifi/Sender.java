package wifi;
import java.util.ArrayDeque;
import java.util.HashMap;

import rf.RF;

/**
 *
 * Threaded sender that continually checks the channel for idle time to send packets
 * @author Brandon Roberts
 * @author Nate Olderman
 *
 */
public class Sender implements Runnable{
	private RF rf;
	//private long sendTime; //currently not used
	private ArrayDeque<Packet> senderBuf;
	private int backOffCount;
	private int windowSize;
	private HashMap<Short, Integer> seqNums; //key destination, value seqNum

	/**
	 * Makes a new Sender object that continually checks the channel for idle time to send packets
	 * @param theRF the RF layer to send packets out through
	 * @param senderBuffer the queue of packets needing to be sent
	 */
	public Sender(RF theRF, ArrayDeque<Packet> senderBuffer){
		 seqNums = new HashMap<Short, Integer>();
		
		rf = theRF;
		senderBuf = senderBuffer;
		backOffCount = 0;
		windowSize = 1;
	}

	/**
	 * Waits to see if RF channel is idle, and sends when it has information
	 */
	public void run() {
		while(true)
			waitForFrame();
	}

	/**
	 * Waits for frame to become available
	 */
	private void waitForFrame(){
		if(!senderBuf.isEmpty()){ 
			if(senderBuf.peek().getFrameType() == 1){				// this is an ACK
				waitForIdleChannelToACK();							// checks if channel is idle and then waits SIFS
				rf.transmit(senderBuf.peek().toBytes());
			}
			
			if(!rf.inUse())
				waitIFS();
			else
				waitForIdleChannel();
		}
		else{
			try{
				Thread.currentThread().sleep(10);
			}catch(InterruptedException e){
				System.err.println("Sender interrupted!");
			}
		}
	}

	/**
	 * Does an extended IFS because of 
	 */
	private void backOffWaitIFS(){
		int difs = RF.aSIFSTime *3; //making up a time for DIFS because we havent experimented yet
		try {
			Thread.currentThread().sleep(difs);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		
		if(backOffCount !=0){
			backOffCount--;
			waitSlotTime();
		}else{
			if(rf.inUse()){
				waitForIdleChannel();
			}
			else{
				rf.transmit(senderBuf.peek().toBytes());
				waitForAck();
			}
		}
			
	}
	
	/**
	 * Waits a slot time
	 */
	private void waitSlotTime(){
		try {
			Thread.currentThread().sleep(RF.aSlotTime);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		if(rf.inUse())
			waitForIdleChannel();
		else{
			backOffCount--;
			waitSlotTime();
		}
	}

	/**
	 * Waits the IFS time *************************Need to update for waiting SIFS
	 */
	private void waitIFS(){
		int difs = RF.aSIFSTime *3;	//making up a time for DIFS because we havent experimented yet

		try {
			Thread.currentThread().sleep(difs);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		if(!rf.inUse()){
			rf.transmit(senderBuf.peek().toBytes());
			waitForAck();
		}else{ 
			waitForIdleChannel();
		}
	}
	
	/**
	 * Waits for the SIFS time
	 */
	private void waitSIFS(){
		try {
			Thread.currentThread().sleep(RF.aSIFSTime);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		if(rf.inUse())
			waitForIdleChannelToACK();
	}
	
	/**
	 * 
	 */
	private void waitForIdleChannelToACK(){
		while(rf.inUse()){
			try{
				Thread.currentThread().sleep(10);
			}catch(InterruptedException e){
				System.err.println("Sender interrupted!");
			}
		}
		waitSIFS();
	}

	/**
	 * Waint
	 */
	private void waitForAck(){
		long startTime = rf.clock();

		while(!senderBuf.peek().isAcked()){
			
			if(rf.clock()-startTime>= 100){
				windowSize *=2; 		//double window size
				backOffCount = (int) (Math.random()*(windowSize + 1)); //give the option to roll a zero
				if(rf.inUse())
					waitForIdleChannel();
				 else 
					 backOffWaitIFS();
			} else{
				try {
					Thread.currentThread().sleep(5);
				} catch (InterruptedException e) {
					System.err.println("Failed waiting for ACK");
				}
			}
		}
		windowSize = 1; //resetting window size
		senderBuf.pop(); //since it is acked we pull it off
	}

	/**
	 * Returns true when the channel becomes idle
	 */
	private void waitForIdleChannel(){
		while(rf.inUse()){
			try{
				Thread.currentThread().sleep(10);
			}catch(InterruptedException e){
				System.err.println("Sender interrupted!");
			}
		}
		backOffWaitIFS();
	}
}