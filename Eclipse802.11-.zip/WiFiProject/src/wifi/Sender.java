package wifi;
import java.util.ArrayDeque;
import java.util.HashMap;

import rf.RF;

/**
 *
 * Threaded sender that continually checks the channel for idle time to send packets
 * @author Brandon Roberts
 * @author Nate Olderman
 *
 */
public class Sender implements Runnable{
	private RF rf;
	//private long sendTime; //currently not used
	private ArrayDeque<Packet> senderBuf;
	private int backOffCount;
	private int windowSize;
	
	private static final int DIFS = RF.aSIFSTime + (2* RF.aSlotTime);
	
	/**
	 * Makes a new Sender object that continually checks the channel for idle time to send packets
	 * @param theRF the RF layer to send packets out through
	 * @param senderBuffer the queue of packets needing to be sent
	 */
	public Sender(RF theRF, ArrayDeque<Packet> senderBuffer){
		rf = theRF;
		senderBuf = senderBuffer;
		backOffCount = 0;
		windowSize = 1;
	}
	
	/**
	 * Waits to see if RF channel is idle, and sends when it has information
	 */
	public void run() {
		while(true)
			waitForFrame();
	}

	/**
	 * Waits for frame to become available
	 */
	private void waitForFrame(){
		if(!senderBuf.isEmpty()){
			if(senderBuf.peek().getFrameType() == 1){				// this is an ACK
				waitForIdleChannelToACK();							// checks if channel is idle and then waits SIFS
				rf.transmit(senderBuf.peek().toBytes());
			}
			
			if(!rf.inUse())
				waitIFS();
			else
				waitForIdleChannel();
		}
		else{
			try{
				Thread.sleep(10);
			}catch(InterruptedException e){
				System.err.println("Sender interrupted!");
			}
		}
	}

	/**
	 * Does an extended IFS wait because the channel was not initially idle
	 */
	private void backOffWaitIFS(){
		try {
			Thread.sleep(DIFS);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		
		if(backOffCount !=0){
			backOffCount--;
			waitSlotTime();
		}else{
			if(rf.inUse()){
				waitForIdleChannel();
			}
			else{
				rf.transmit(senderBuf.peek().toBytes());
				waitForAck();
			}
		}
	}
	
	/**
	 * Waits a slot time
	 */
	private void waitSlotTime(){
		try {
			Thread.sleep(RF.aSlotTime);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		if(rf.inUse())
			waitForIdleChannel();
		else{
			backOffCount--;								//********************************what if the count gets to zero?**********************
			waitSlotTime();
		}
	}

	/**
	 * Waits the IFS time 
	 */
	private void waitIFS(){
			//making up a time for DIFS because we havent experimented yet
		try {
			Thread.sleep(DIFS);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		if(!rf.inUse()){
			rf.transmit(senderBuf.peek().toBytes());
			waitForAck();
		}else{ 
			waitForIdleChannel();
		}
	}
	
	/**
	 * Waits for the SIFS time
	 */
	private void waitSIFS(){
		try {
			Thread.sleep(RF.aSIFSTime);
		} catch (InterruptedException e) {
			System.err.println("Failed waiting IFS");
		}
		if(rf.inUse())
			waitForIdleChannelToACK();
	}
	
	/**
	 * Waits until the channel is available then waits SIFS
	 */
	private void waitForIdleChannelToACK(){
		while(rf.inUse()){
			try{
				Thread.sleep(10);
			}catch(InterruptedException e){
				System.err.println("Sender interrupted!");
			}
		}
		waitSIFS();
	}

	/**
	 * Wait
	 */
	private void waitForAck(){
		long startTime = rf.clock();
		System.out.println("SENDER calling isAcked() : "+senderBuf.peek().isAcked());
		while(!senderBuf.peek().isAcked()){
			if(rf.clock()-startTime >= 100){ 	 //if it has taken longer than a tenth of a second timeout
				windowSize *=2; 				//double window size
				backOffCount = (int) (Math.random()*(windowSize + 1)); //give the option to roll a zero
				if(senderBuf.peek().retry()  >= RF.dot11RetryLimit)  //hit retry limit and it breaks so that it will pull it off the buffer
					break;
				if(rf.inUse())
					waitForIdleChannel();
				 else 
					 backOffWaitIFS();
			} else{
				try {
					Thread.sleep(5);
				} catch (InterruptedException e) {
					System.err.println("Failed waiting for ACK");
				}
			}
		}
		windowSize = 1; //resetting window size
		senderBuf.pop(); //since it is acked we pull it off
	}

	/**
	 * Returns true when the channel becomes idle
	 */
	private void waitForIdleChannel(){
		while(rf.inUse()){
			try{
				Thread.sleep(10);
			}catch(InterruptedException e){
				System.err.println("Sender interrupted!");
			}
		}
		backOffWaitIFS();
	}
	
}