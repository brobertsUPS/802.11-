package wifi;
import rf.RF;

import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.*;
import java.util.*;


/**
 *
 * Threaded Receiver that continually watches the RF layer for incoming information
 * @author Brandon Roberts
 * @author Nate Olderman
 *
 */
public class Receiver implements Runnable {
	private RF rf;
	//private long recvTime;//currently not used
	private ArrayDeque<Packet> senderBuf;
	private ArrayBlockingQueue<Packet> receiverBuf;
	private short ourMac;
	
	private PrintWriter output;
	
	private HashMap<Short, Short> recvSeqNums; 				//expected seqNum for stuff we get from other hosts
	private HashMap<Short, ArrayList<Packet>> outOfOrderTable;	//packets that have a higher seqNum than we are expecting for the srcAddress
	
	/**
	 * Makes a new Receiver object that watches the RF layer for incoming information
	 * @param theRF the RF layer to receive from
	 * @param senderBuffer the queue of packets needing to be sent (use in Reciever to confirm ACK)
	 * @param receiverBuffer the que of received packets
	 */
	public Receiver(RF theRF, ArrayDeque<Packet> senderBuffer, ArrayBlockingQueue<Packet> receiverBuffer, short theMac, PrintWriter outputWriter){
		rf = theRF;
		senderBuf = senderBuffer;
		receiverBuf = receiverBuffer;
		ourMac = theMac;
		recvSeqNums = new HashMap<Short, Short>();
		outOfOrderTable = new HashMap<Short, ArrayList<Packet>>();
		output = outputWriter;
	}
	
	/**
	 * Begins waiting for the rf layer to receive and puts it in the receiverBuf
	 */
	public void run() {
		while(true){
			try {
				Packet packet = new Packet(rf.receive());
				if(packet.getDestAddr() == ourMac){
					//if its an ack AND it has the same sequence number
					//tell sender through the packet it is waiting on, that that packet was ACKed
					System.out.println("RECEIVER run(): Packet.getFrameType " + packet.getFrameType() + " PACKET SEQNUM: "+ packet.getSeqNum() + " SenderBUF SEQNUM: "+ senderBuf.peek().getSeqNum());
					if((packet.getFrameType() == 1)  &&  (packet.getSeqNum() == senderBuf.peek().getSeqNum()))
						senderBuf.peek().setAsAcked();
					else{
						short expectedSeqNum;
						if(!recvSeqNums.containsKey(packet.getSrcAddr())){
							recvSeqNums.put(packet.getSrcAddr(), (short)0); //assuming it starts at zero
							expectedSeqNum = 0;
							
							outOfOrderTable.put(packet.getSrcAddr(), new ArrayList<Packet>());
						}
						else
							expectedSeqNum = recvSeqNums.get(packet.getSrcAddr()).shortValue();
	
						ArrayList<Packet> packets = outOfOrderTable.get(packet.getSrcAddr());
						if(expectedSeqNum == packet.getSeqNum()){
							receiverBuf.put(packet);		//if received successfully we need to put an ack in senderBuf

							//if there are things waiting
							if(!packets.isEmpty()){
								//for everything in the arraylist, put it on the recieverbuffer until you hit a gap
								for (Packet queuedPacket : packets) {
									if(queuedPacket == null)
										break;
									
									receiverBuf.put(packet);
								}
							}
						}
						else if(expectedSeqNum < packet.getSeqNum()){ 
							output.println("Detected a gap in the sequence nmbers on incoming data packets from host: " + packet.getSrcAddr());
							packets.add(packet.getSeqNum() - expectedSeqNum - 1, packet);//adding the packet to the spot in the arraylist corresponding to the distance from the expected sequence number -1 to maintain starting at 0
						}
						//don't put it on the buffer if the received sequence number is less than the expected because we already got it
						
						recvSeqNums.put(packet.getSrcAddr(), (short)(expectedSeqNum+1));
						
						//change the packet into an ACK and just send it back out to the other host
						packet.makeIntoACK();
						senderBuf.addFirst(packet);
					}
					
				}				
			} catch (InterruptedException e) {
				System.err.println("Receiver interrupted!");
			}
		}
	}	
}